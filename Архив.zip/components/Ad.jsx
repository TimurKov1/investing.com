const Ad = ({ width, height }) => {
  // Тут будет магия с рекламой

  return (
    <div style={{ width, height, backgroundColor: '#f5f5f5' }}></div>
  )
}

export default Ad