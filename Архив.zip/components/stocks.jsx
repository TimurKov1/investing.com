import styles from '../styles/Stock.module.scss'

const Stocks = ({ stocks, onRemove }) => (
  <div className={styles.stockSec}>
    <div className={styles.stockSec__item}>

    </div>
    <div className={styles.stockSec__item}>

    </div>
    <div className={styles.stockSec__item}>

    </div>
    <div className={styles.stockSec__item}>

    </div>
  </div>
);

export default Stocks;